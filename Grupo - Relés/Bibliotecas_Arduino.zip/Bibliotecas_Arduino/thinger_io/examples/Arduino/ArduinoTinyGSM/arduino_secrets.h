#define USERNAME "your_user_name"
#define DEVICE_ID "your_device_id"
#define DEVICE_CREDENTIAL "your_device_credential"

// use your own APN config
#define APN_NAME "your_apn_name"
#define APN_USER "your_apn_user"
#define APN_PSWD "your_apn_password"

// set your cad pin (optional)
#define CARD_PIN ""